import java.util.*;
/**
 *Adam McEnroe
 *C15304081
 */
public class Passenger
{
    String passengerName;
        String address;
        String email;
        Flight passengerID;
        boolean passengerBooking;
    
    public Passenger()
    {
        this.passengerName = "";
        this.address = "";
        this.email = "";
        this.passengerID = null;
        this.passengerBooking = false;
    }

    public Passenger(String name, String address, String email, Flight ID, boolean pb)
    {
        this.passengerName = name;
        this.address = address;
        this.email = email;
        this.passengerID = ID;
        this.passengerBooking = pb;
    }
    
    //Accessor/Getter methods for first 5 instance variables
    public String getPassengerName()
    {
        return this.passengerName;
    }

    public String getAddress()
    {
        return this.address;
    }

    public String getEmail()
    {
        return this.email;
    }
    
    public Flight getID()
    {
        return this.passengerID;
    }
    
    public boolean getPassengerBooking()
    {
        return this.passengerBooking;
    }
    //Mutator/Setter methods for first 3 instance variables
    public void setPassengerName(String name)
    {
        this.passengerName= name;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }
    
    public void setID(Flight ID)
    {
        this.passengerID = ID;
    }

    public void setPassengerBooking(boolean pb)
    {
        this.passengerBooking = pb;
    }

    public void display()
    {
        System.out.println("\n\nPassenger Name: " + this.passengerName);
        System.out.println("Address: " + this.address);
        System.out.println("Email: " + this.email);
        System.out.println("Booked on this flight: " + this.address);
        this.passengerID.display();
    }
   
    
    
    
    
    
    
    
    
    
}
