import java.util.*;
/**
 * Adam McEnroe
 * C15304081
 */
public class Flight
{
    private String flightNum;
    private String day;
    private String destination;
    private int seatsBooked;
    
    public Flight()
    {
        this.flightNum = "";
        this.day = "";
        this.destination = "";
        this.seatsBooked = 0;

    }

    public Flight(String num, String day, String location, int seats)
    {
        this.flightNum = num;
        this.day = day;
        this.destination = location;
        this.seatsBooked = seats;

    }
    
    //Accessor/Getter methods for first 5 instance variables
    public String getflightNumber()
    {
        return this.flightNum;
    }

    public String getDay()
    {
        return this.day;
    }

    public String getDestination()
    {
        return this.destination;
    }
    
    public int getSeatsBooked()
    {
        return this.seatsBooked;
    }
    
    //Mutator/Setter methods for first 3 instance variables
    public void setFlightNum(String num)
    {
        this.flightNum = num;
    }

    public void setDay(String day)
    {
        this.day = day;
    }

    public void setDestination(String location)
    {
        this.destination = location;
    }
    
    public void setSeatsBooked(int seats)
    {
        this.seatsBooked = seats;
    }
    
    public int seatsAvailable()
    {
        int availableSeats;
        
        availableSeats = 10 - seatsBooked;
        
        return availableSeats;
        
        
    }
    
    public void updateBookedSeats()
    {
        seatsBooked = seatsBooked + 1;
        
    }

    public void display()
    {
        System.out.println("\n\nFlight Number : " + this.flightNum);
        System.out.println("Day of departure : " + this.day);
        System.out.println("Destination : " + this.destination);
    }
}
