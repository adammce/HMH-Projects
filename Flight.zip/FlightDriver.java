import java.util.*;
import java.text.*;
/**
 * Adam McEnroe
 * C15304081
 */
public class FlightDriver
{
    Flight [] flightList;
    final int FLIGHTLIST = 5;
    Passenger [] Plist;
    final int PASSENGERLIST = 10;
    int seatsBooked; 

    public void FlightDriver()
    {
        flightList = new Flight[FLIGHTLIST];
        Plist = new Passenger[PASSENGERLIST];
    }

    Scanner scan = new Scanner(System.in);

   /* public void createFlight()
    {
        Flight flight1, flight2, flight3;

        flight1 = new Flight("EI354", "Marracech", "Friday", 0);
        flightList[0] = flight1;
        flight2 = new Flight("EI664", "Dubai", "Sunday", 0);
        flightList[1] = flight2;
        flight3 = new Flight("EI977", "London", "Wednesday", 0);
        flightList[2] = flight3;

        
    }*/
    
    public void createFlight()
    {
        //local variables
        String flightNum;
        String day;
        String destination;
        int seatsBooked = 0;
        Flight flight1, flight2, flight3;
        

        for (int count = 0; count < FLIGHTLIST; count++)
        {
            System.out.print("Enter flight number: ");
            flightNum = scan.nextLine();
            
            System.out.print("Enter day of departure: ");
            day = scan.nextLine();
            
            System.out.print("Enter destination: ");
            destination = scan.nextLine();
            
            System.out.print("Enter number of seats booked: ");
            seatsBooked = scan.nextInt();
            scan.nextLine();

            flight1 = new Flight(flightNum, day, destination, seatsBooked);

            flightList[count] = flight1;

        }
    }

    public void makeBooking()
    {
        String flightNum;
        String day;
        String destination;
        int seatsBooked = 0;
        Passenger passenger0;

        String passengerName;
        String address;
        String email;
        Flight passengerFlight;
        boolean passengerBooking;

        System.out.println("Enter destination");
        destination = scan.nextLine();

        System.out.println("Enter day");
        day = scan.nextLine();

        for(int count = 0; count < FLIGHTLIST; count++)
        {
          if(flightList[count].getDestination().equalsIgnoreCase(destination) && flightList[count].getDay().equalsIgnoreCase(day))
          {
              System.out.println("Enter your details to proceed with your booking");
              
              System.out.println("Enter passenger name");
              passengerName = scan.nextLine();
              
              System.out.println("Enter passenger address");
              address = scan.nextLine();
              
              System.out.println("Enter passenger email");
              email = scan.nextLine();
              
              System.out.println("How many seats would you like to book?");
              seatsBooked = scan.nextInt();
              
              passenger0 = new Passenger(passengerName, address, email, flightList[count], true);
              Plist[seatsBooked] = passenger0;
              Plist[seatsBooked].display();
              seatsBooked = seatsBooked + 1;
              
              System.out.println("Your flight has been successfully booked!");
              
              
              
              
          }
             
        }
    
        
    }

    public void displayMenu()
    {
        System.out.println("1. Make a Booking");
        System.out.println("1. Cancel a Booking");
        System.out.println("3. Display Full Flight Schedule");
        System.out.println("4. Display Passenger Bookings");
        System.out.println("5. Menu option which will ustilise your personal flight responsibility");
        System.out.println("6. Menu option which will ustilise your personal passenger responsibility");
        System.out.println("7. Exit System");
    }
    
    
    /*public void cancelBooking()
    {
         String name = "";
         boolean found = false;
         String flightNum;
         String passengerName;
         
         System.out.println ("Enter your name: ");
         passengerName = scan.nextLine();
         
         for (int i = 0; i < FLIGHTLIST; i++)
         {
             if(name == flightList[i].getPassengerName())
             {
              
                 found = true;
                 
             }
             
             System.out.println("Enter Flight Number: ");
             flightNum = scan.nextLine();
             
             if(flightNum == flightList[i].getPassengerID().getFlightNum())
             {
                 int seatsBooked = seatsBooked--;
                 passengerName = "";
                 flightList[i].setPassengerID(null);
             }
             
             
             
         }
    }*/
    
    public void displayFlightSchedule()
    {
        for (int i = 0; i < 5; i++)
        {
            
            flightList[i].display();
            
        }
    }
    
    public void displayPassengerBooking()
    {
        for(int i = 0; i < PASSENGERLIST; i++)
        {
            
           Plist[i].display();
            
        }
    }
    
    
    public void menu()
    {
        displayMenu();
        int menuChoice = 0;

        menuChoice = scan.nextInt();
        scan.nextLine();

        while (menuChoice != 7)
        {
            if (menuChoice == 1)
            {
                makeBooking();
            }

            else if (menuChoice == 2)
            {
                //cancelBooking();
            }

            else if (menuChoice == 3)
            {
                displayFlightSchedule();
            }

            else if (menuChoice == 4)
            {
                displayPassengerBooking();
            }

            if (menuChoice == 5)
            {
                //();
            }

            if (menuChoice == 6)
            {
                //();
            }

            else 
            {
                System.out.println("Wrong. Please choose an option between 1-7 ");
            }
        }
    }

   public static void main (String[]args)
     {
        FlightDriver driver;
        driver = new FlightDriver();
        driver.createFlight();
        driver.menu();
        

            
      }
}
