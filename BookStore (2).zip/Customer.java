
public class Customer
{
    // instance variables - replace the example below with your own
    private String name;
    private String address;
    private boolean hasSub;
    private Book bookBought;

   
    public Customer(String n, String ad, boolean h, Book book)
    {
        this.name = n;
        this.address = ad;
        this.hasSub = h;
        this.bookBought = book;
    }
    public boolean getHasSub()
    {
        return this.hasSub;
    }
  public void display()
    {
        System.out.println("Name: " + this.name);
        System.out.println("Address: " + this.address);
        System.out.println("Subscription valid : " + this.hasSub);
        
        if (bookBought!= null)
        {
            
            
        }
    }
}
    
