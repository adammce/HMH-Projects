
/**
 * Write a description of class Book here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Book
{
    // instance variables - replace the example below with your own
    private String idNum;
    private String title;
    private String author;
    private double cost;


    /**
     * Constructor for objects of class Book
     */
    public Book(String id, String t, String a, double c )
    {
        this.idNum = id;
        this.title = t;
        this.author = a;
        this.cost = c;
    }

    public String getID()
    {
        return this.idNum;
    }

    public String getTitle()
    {
        return this.title;
    }
    
    public double getCost()
    {
        return this.cost;
    }
   
    
    public String getAuthor()
    {
        return this.author;
    }
    
    public void setId(String id)
    {
        this.idNum = id;
    }

    public void setTitle(String t)
    {
         this.title = t;
    }

    public void setAuthor(String a)
    {
        this.author = a;
    }
    
    public void setCost(double c)
    {
          this.cost = c;
    }
    
    public void display()
    {
        System.out.println("ID number: " + this.idNum);
        System.out.println("Title : " + this.title);
        System.out.println("Author : " + this.author);
        System.out.println("Cost : " + this.cost);
    }
}
