import java.util.*;
public class Shop
{
    private ArrayList<Customer> customers;
    private ArrayList<Book> books;

    /**
     * Constructor for objects of class Shop
     */
    public Shop()
    {
       customers = new ArrayList<Customer>();
       books = new ArrayList<Book>();
    }

    public void createPBook()
    {
       physicalBook pbook1 = new physicalBook("45D19", "Hello", "JK. Rowling", 10.00, 2.00, 400);
       physicalBook pbook2 = new physicalBook("45D19", "Hello", "JK. Rowling", 10.00, 2.00, 400);
       physicalBook pbook3 = new physicalBook("45D19", "Hello", "JK. Rowling", 10.00, 2.00, 400);
       books.add(pbook1);
       books.add(pbook2);
    }
    
    public void createCustomers()
    {
        //Customer customer1 = new Customer("John", "41 hello", false);
        //Customer customer1 = new Customer("John", "41 hello", true);
        //customers.add(customer1);
        //customers.add(customer2);
    }
    
    public void DisplayAllCost()
    {
        double totalCost = 0.00;
        for (Book book: books)
        {
          totalCost = totalCost + book.totalCost();   
            
        }
        System.out.println("The total cost of all books: " + totalCost);
    }
    
    public void buyBook()
    {
        String cName = "";
        String cAddress = "";
        boolean cHasSub = "";
        String title = "";
        boolean found = false;
        boolean cFound = false;
        Scanner scan = new Scanner(System.in);
        System.out.println("What is the ID of the book you wish to purchase? :");
        System.out.println("What is your name : ");
        title = scan.nextLine();
        cName = scan.nextLine();
        if (!books.isEmpty())
        {
            for (Book book: books)
            {
                if (book.getID().equalsIgnoreCase(id))
                {
                  found = true;
                  System.out.println("Enter your name>");
                  cName = scan.nextLine();
                  System.out.println("Enter your address>");
                  cAddress = scan.nextLine();
                  System.out.println("Do you have a subscription>");
                  cHasSub = scan.nextBoolean();
                  scan.nextLine();
                  Customer customer = new Customer(cName, cAddress, cHasSub );
                  customers.add(customer);
                  
                  if(book instanceof eBook)
                  {
                      System.out.println("You have bought a book");
                      if (customer.getHasSub)
                      {
                          System.out.println("Total cost of books:" + book.totalCost());
                      }
                  }
                  
                  else 
                  {
                      System.out.println("Total cost of books(including subs):" + book.totalCost() + 20);
                  }
                }
            }
            
            if (!found)
            {
                System.out.println("We dont have a book with that title");
            }
        }
        else 
        {
            System.out.println("There are no books left.");
        }
    }
    
    public void displayCustomers()
    {
        for (Customer customer: customers)
        {
            
            customer.display();
        }
        
    }
    
    public void displayBooks()
    {
        for (Book book: books)
        {
            
            customer.displayBooks();
        }
        
    }
}
