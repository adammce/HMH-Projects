
public class physicalBook extends Book
{
    // instance variables - replace the example below with your own
    private static double TAXRATE = 0.10;
    private double deliveryCost;
    private int numPages;
    private int deliveryDays;

    /**
     * Constructor for objects of class physicalBook
     */
    public physicalBook(String id, String t, String a, double c, double dc, int np)
    {
        super(id, t, a, c);
        this.deliveryCost = dc;
        this.numPages = np;
        this.deliveryDays = this.numPages / 20;
    }

    public double totalCost()
    {
        return this.getCost() + (this.getCost() * TAXRATE) + this.deliveryCost;
    }
    

    public void display()
    {
        super.display();
        System.out.println("Delivery cost : " + this.deliveryCost);
        System.out.println("Number of pages in this book: " +this.numPages);
    }
}
