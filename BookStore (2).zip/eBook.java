
/**
 * Write a description of class eBook here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class eBook extends Book
{
       // instance variables - replace the example below with your own
    private static double TAXRATE = 0.05;
    private static int SUBS = 20;

    /**
     * Constructor for objects of class physicalBook
     */
    public eBook(String id, String t, String a, double c)
    {
        super(id, t, a, c);
    }

    public double totalCost()
    {
      return this.getCost() + (this.getCost() * TAXRATE);
    }
    
    public void display()
    {
        super.display();
        System.out.println("Annual subscriptions" + this.SUBS);
    }
}
